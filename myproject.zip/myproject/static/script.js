// Notification Dropdown Functionality

// Toggle notification dropdown and load notifications
function toggleNotifDropdown() {
  const dropdown = document.getElementById('notif-dropdown');
  dropdown.classList.toggle('show');
  
  if (dropdown.classList.contains('show')) {
    loadNotifications();
  }
}

// Load notifications when dropdown is opened
function loadNotifications() {
  const dropdown = document.getElementById('notif-dropdown');
  
  // Check if dropdown is being shown
  if (!dropdown.classList.contains('show')) {
    return;
  }
  
  fetch('/notifications/api/get/')
    .then(response => response.json())
    .then(data => {
      const notificationsList = document.getElementById('notifications-list');
      
      if (data.notifications.length === 0) {
        notificationsList.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--text3);">No notifications</div>';
        return;
      }
      
      notificationsList.innerHTML = data.notifications.map(notif => `
        <div class="notif-item" data-notif-id="${notif.id}" onclick="markNotificationRead(event, ${notif.id})">
          <div class="notif-dot ${notif.is_read ? 'read' : ''}"></div>
          <div>
            <div class="notif-text">${escapeHtml(notif.message)}</div>
            <div class="notif-time">${notif.created_at}</div>
          </div>
        </div>
      `).join('');
    })
    .catch(error => console.error('Error loading notifications:', error));
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

// Mark a single notification as read
function markNotificationRead(event, notificationId) {
  event.preventDefault();
  
  fetch(`/notifications/${notificationId}/read/`, {
    method: 'POST',
    headers: {
      'X-CSRFToken': getCookie('csrftoken'),
      'Content-Type': 'application/json'
    }
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Update the notification item in the UI
      const notifItem = document.querySelector(`[data-notif-id="${notificationId}"]`);
      if (notifItem) {
        notifItem.querySelector('.notif-dot').classList.add('read');
      }
      
      // Update notification count
      updateNotificationCount();
    }
  })
  .catch(error => console.error('Error marking notification as read:', error));
}

// Mark all notifications as read
function markAllNotificationsRead() {
  fetch('/notifications/api/mark-all-read/', {
    method: 'POST',
    headers: {
      'X-CSRFToken': getCookie('csrftoken'),
      'Content-Type': 'application/json'
    }
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Mark all items as read in the UI
      document.querySelectorAll('.notif-dot').forEach(dot => {
        dot.classList.add('read');
      });
      
      // Update notification count
      document.getElementById('notif-count').textContent = '0';
    }
  })
  .catch(error => console.error('Error marking all notifications as read:', error));
}

// Update notification count
function updateNotificationCount() {
  fetch('/notifications/unread-count/')
    .then(response => response.json())
    .then(data => {
      document.getElementById('notif-count').textContent = data.count;
    })
    .catch(error => console.error('Error updating notification count:', error));
}

// Get CSRF token from cookies
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === (name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

// Refresh notifications periodically (every 30 seconds)
setInterval(function() {
  const dropdown = document.getElementById('notif-dropdown');
  if (dropdown && dropdown.classList.contains('show')) {
    loadNotifications();
  }
  updateNotificationCount();
}, 30000);

// Initialize notification count on page load
document.addEventListener('DOMContentLoaded', function() {
  updateNotificationCount();
});
